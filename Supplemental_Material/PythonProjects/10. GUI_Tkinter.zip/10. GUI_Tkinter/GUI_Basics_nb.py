#uses Tkinter 
#thenewboston

from tkinter import *

root = Tk() #creates a blank window i.e. a constructor
theLabel = Label(root, text = "this is way too easy") #the window expands to the test length

theLabel.pack() #pack theLabel wherever you want in the window

root.mainloop() #this keeps the window open until you close it



