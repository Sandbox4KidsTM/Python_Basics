#errors in loops
# Syntax errors are also called parsing errors

apple = 1

while apple < 10: #missing colon
    print(uggh)     # NameError: name 'uggh' is not defined
        apple = apple + 1 #indentation error 



#print("How are you?) # SyntaxError: EOL while scanning string literal
#print('I am fine") #SyntaxError: EOL while scanning string literal
print("You are graetrrrrrr!")