# -*- coding: utf-8 -*-

#print("apple pie" SyntaxError: unexpected EOF while parsing

print("this is the first line\n" +
      "and the second line\n" + 
           "and the third line\n")
#parentesis doesn't have to end on the same line