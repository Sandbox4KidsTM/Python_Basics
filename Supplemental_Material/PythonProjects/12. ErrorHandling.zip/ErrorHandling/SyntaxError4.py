# -*- coding: utf-8 -*-

Counterrr=0
#while counter < 5: #W in While should be lowercase, as Python is case-sensitive
while Counterrr < 5: #c in Counter should be same case as as its definition
    print("hello")
    Counterrr = Counterrr + 1